package Lab;

public interface Sellable {
    Double getPrice();
}
