import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        String[] elements = scanner.nextLine().split(" ");
//        int count = Integer.parseInt(scanner.nextLine());
//
//        Collection addCollection = new AddCollection();
//        AddRemoveCollection addRemoveCollection = new AddRemoveCollection();
//        MyListImpl myListImpl = new MyListImpl();
//
//        for (String element : elements) {
//            System.out.print(addCollection.add(element) + " ");
//        }
//        System.out.println();
//
//        for (String element : elements) {
//            System.out.print(addRemoveCollection.add(element) + " ");
//        }
//        System.out.println();
//
//        for (String element : elements) {
//            System.out.print(myListImpl.add(element) + " ");
//        }
//        System.out.println();
//
//        for (int i = 0; i < count; i++) {
//            System.out.print(addRemoveCollection.remove() + " ");
//        }
//        System.out.println();
//
//        for (int i = 0; i < count; i++) {
//            System.out.print(myListImpl.remove() + " ");
//        }
//        System.out.println();
    }
}
