package Lab;

public interface Rentable {
    Integer getMinRentDay();
    Double getPricePerDay();
}
