package Lab;

public interface Identifiable {
    String getId();
}
