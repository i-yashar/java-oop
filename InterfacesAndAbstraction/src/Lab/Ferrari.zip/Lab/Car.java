package Lab;

public interface Car {
    String brakes();
    String gas();
}
