import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        int n = Integer.parseInt(scanner.nextLine());

        List<Integer> trafficLights = parseInputToLights(input);

        while(n-- > 0){
            changeLights(trafficLights);
            printLights(trafficLights);
        }
    }

    private static void printLights(List<Integer> trafficLights) {
        for (Integer value : trafficLights) {
            System.out.print(Light.values()[value] + " ");
        }
        System.out.println();
    }

    private static void changeLights(List<Integer> trafficLights) {
        for (int i = 0; i < trafficLights.size(); i++) {
            trafficLights.set(i, (trafficLights.get(i) + 1) % 3);
        }
    }

    private static List<Integer> parseInputToLights(String input) {
        String[] tokens = input.split(" ");

        List<Integer> list = new ArrayList<>();

        for (String light : tokens) {
            list.add(Light.valueOf(light.toUpperCase()).ordinal());
        }

        return list;
    }
}
