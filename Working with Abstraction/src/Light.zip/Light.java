public enum Light {
    RED,
    GREEN,
    YELLOW;
}
