import java.util.HashMap;
import java.util.Map;

public class StudentSystem {
    private Map<String, Student> studentRecords;

    public StudentSystem()
    {
        this.studentRecords = new HashMap<>();
    }

    public Map<String, Student> getStudentRecords() {
        return this.studentRecords;
    }

    public void ParseCommand(String input)
    {
        String[] args = input.split(" ");

        if (args[0].equals("Create"))
        {
            String name = args[1];

            studentRecords.putIfAbsent(name, createNewRecord(args));
        }
        else if (args[0].equals("Show"))
        {
            String name = args[1];
            if (studentRecords.containsKey(name))
            {
                StringBuilder output = new StringBuilder();

                Student student = studentRecords.get(name);

                output.append(student.toString());
                output.append(" ");
                output.append(assessStudent(student.getGrade()));

                System.out.println(output);
            }
        }
    }

    private Student createNewRecord(String[] args) {
        return new Student(args[1], Integer.parseInt(args[2]), Double.parseDouble(args[3]));
    }

    private String assessStudent(double grade){
        if (grade >= 5.00)
        {
            return "Excellent student.";
        }
        else if (grade < 5.00 && grade >= 3.50)
        {
            return "Average student.";
        }
        else
        {
            return "Very nice person.";
        }
    }
}
