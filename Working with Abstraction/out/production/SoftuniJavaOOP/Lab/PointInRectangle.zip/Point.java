public class Point {
    private int x;
    private int y;

    public Point(int x, int y){
        this.x = x;
        this.y = y;
    }

    public boolean isWithinXBounds(Point firstBound, Point secondBound){
        return this.x >= firstBound.x && this.x <= secondBound.x;
    }

    public boolean isWithinYBounds(Point firstBound, Point secondBound){
        return this.y >= firstBound.y && this.y <= secondBound.y;
    }
}
