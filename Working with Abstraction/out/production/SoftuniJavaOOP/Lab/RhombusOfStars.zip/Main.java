import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 1; i <= n; i++) {
            printRow(" ", n - i, "* ", i);
            System.out.println();
        }
        for (int i = 1; i < n; i++) {
            printRow(" ", i, "* ", n - i);
            System.out.println();
        }
    }

    public static void printRow(String firstSymbol, int firstSymbolCount, String secondSymbol, int secondSymbolCount){
        StringBuilder line = new StringBuilder();

        for (int i = 0; i < firstSymbolCount; i++) {
            line.append(firstSymbol);
        }

        for (int i = 0; i < secondSymbolCount; i++) {
            line.append(secondSymbol);
        }

        System.out.print(line);
    }
}
