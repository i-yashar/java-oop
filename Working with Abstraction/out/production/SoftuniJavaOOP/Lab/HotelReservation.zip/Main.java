import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        processInput(input);
    }

    private static void processInput(String input) {
        double pricePerDay = Double.parseDouble(input.split(" ")[0]);
        int numberOfDays = Integer.parseInt(input.split(" ")[1]);
        String season = input.split(" ")[2].toUpperCase();
        String discount = input.split(" ")[3].equals("SecondVisit") ? "SECOND_VISIT" : input.split(" ")[3].toUpperCase();

        PriceCalculator priceCalculator = new PriceCalculator(pricePerDay, numberOfDays, Season.valueOf(season), Discount.valueOf(discount));

        double totalPrice = priceCalculator.calculate();

        System.out.printf("%.2f", totalPrice);
    }
}
