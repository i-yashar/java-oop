import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String rank = scanner.nextLine().toUpperCase();
        String suit = scanner.nextLine().toUpperCase();

        System.out.printf("Card name: %s of %s; Card power: %d%n", Rank.valueOf(rank).name(), Suit.valueOf(suit).name(), Rank.valueOf(rank).getPower() + Suit.valueOf(suit).getPower());
    }
}
