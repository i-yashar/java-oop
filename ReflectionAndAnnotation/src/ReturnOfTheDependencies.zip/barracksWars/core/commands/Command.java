package barracksWars.core.commands;

import barracksWars.interfaces.Executable;

public abstract class Command implements Executable {

}
