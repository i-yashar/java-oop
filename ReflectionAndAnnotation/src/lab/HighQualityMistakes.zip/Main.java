import java.lang.reflect.*;
import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Class clazz = Reflection.class;

        Method[] declaredMethods = clazz.getDeclaredMethods();

        Field[] fields = Arrays.stream(clazz.getDeclaredFields())
                .filter(f -> !Modifier.isPrivate(f.getModifiers()))
                .sorted(Comparator.comparing(Field::getName))
                .toArray(Field[]::new);

        Method[] getters = Arrays.stream(declaredMethods)
                .filter(m -> m.getName().contains("get") && !Modifier.isPublic(m.getModifiers()))
                .sorted(Comparator.comparing(Method::getName))
                .toArray(Method[]::new);

        Method[] setters = Arrays.stream(declaredMethods)
                .filter(m -> m.getName().contains("set") && !Modifier.isPrivate(m.getModifiers()))
                .sorted(Comparator.comparing(Method::getName))
                .toArray(Method[]::new);

        for (Field field : fields) {
            System.out.printf("%s must be private!%n", field.getName());
        }

        for (Method getter : getters) {
            System.out.printf("%s have to be public!%n", getter.getName());
        }

        for (Method setter : setters) {
            System.out.printf("%s have to be private!%n", setter.getName());
        }
    }
}
