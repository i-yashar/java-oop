public abstract class Mammal extends Animal {
    protected Mammal(String name, String type, Double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }
}
