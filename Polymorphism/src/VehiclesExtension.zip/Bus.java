public class Bus extends Vehicle{
    private static final double ADDITIONAL_COST = 1.4;

    public Bus(double fuelQuantity, double fuelConsumption, int tankCapacity) {
        super(fuelQuantity, fuelConsumption + ADDITIONAL_COST, tankCapacity);
    }

    public String driveEmpty(double distance){
        super.setFuelConsumption(super.getFuelConsumption() - ADDITIONAL_COST);
        String result = super.drive(distance);
        super.setFuelConsumption(super.getFuelConsumption() + ADDITIONAL_COST);
        return result;
    }
}
