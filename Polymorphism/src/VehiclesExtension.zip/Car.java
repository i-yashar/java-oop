public class Car extends Vehicle{
    private static final double ADDITIONAL_COST = 0.9;

    public Car(double fuelQuantity, double fuelConsumption, int tankCapacity) {
        super(fuelQuantity, fuelConsumption + ADDITIONAL_COST, tankCapacity);
    }

}
