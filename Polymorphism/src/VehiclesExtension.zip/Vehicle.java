import java.text.DecimalFormat;

public abstract class Vehicle {
    private double fuelQuantity;
    private double fuelConsumption;
    private int tankCapacity;

    public Vehicle(double fuelQuantity, double fuelConsumption, int tankCapacity) {
        this.fuelQuantity = fuelQuantity;
        this.fuelConsumption = fuelConsumption;
        this.tankCapacity = tankCapacity;
    }

    protected void setFuelConsumption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public String drive(double distance) {
        double needed = distance * fuelConsumption;

        if (needed > fuelQuantity) {
            return this.getClass().getSimpleName() + " needs refueling";
        }

        fuelQuantity -= needed;

        DecimalFormat df = new DecimalFormat("##.##");

        return String.format("%s travelled %s km", this.getClass().getSimpleName(), df.format(distance));
    }

    public void refuel(double amount) {
        if (amount <= 0)
            System.out.println("Fuel must be a positive number");
        else{
            if(fuelQuantity + amount > tankCapacity){
                System.out.println("Cannot fit fuel in tank");
            }
            else{
                fuelQuantity = fuelQuantity + amount;
            }
        }
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f", this.getClass().getSimpleName(), this.fuelQuantity);
    }
}
