import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] tokens = scanner.nextLine().split("\\s+");

        Vehicle car = new Car(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Integer.parseInt(tokens[3]));

        tokens = scanner.nextLine().split("\\s+");

        Vehicle truck = new Truck(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Integer.parseInt(tokens[3]));

        tokens = scanner.nextLine().split("\\s+");

        Vehicle bus = new Bus(Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Integer.parseInt(tokens[3]));

        int n = Integer.parseInt(scanner.nextLine());

        while (n-- > 0) {
            tokens = scanner.nextLine().split("\\s+");

            switch (tokens[0]) {
                case "Drive":
                    double distance = Double.parseDouble(tokens[2]);

                    if (tokens[1].equals("Car"))
                        System.out.println(car.drive(distance));
                    else if (tokens[1].equals("Truck")) {
                        System.out.println(truck.drive(distance));
                    } else {
                        System.out.println(bus.drive(distance));
                    }
                    break;
                case "Refuel":
                    double liters = Double.parseDouble(tokens[2]);

                    if (tokens[1].equals("Car"))
                        car.refuel(liters);
                    else if (tokens[1].equals("Truck")) {
                        truck.refuel(liters);
                    } else {
                        bus.refuel(liters);
                    }
                    break;
                case "DriveEmpty":
                    distance = Double.parseDouble(tokens[2]);

                    System.out.println(((Bus) bus).driveEmpty(distance));
            }
        }

        System.out.println(car);
        System.out.println(truck);
        System.out.println(bus);
    }
}
