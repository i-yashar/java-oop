package Lab;

public class Main {
}
