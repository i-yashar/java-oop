public class Truck extends Vehicle{
    private static final double ADDITIONAL_COST = 1.6;

    public Truck(double fuelQuantity, double fuelConsumption) {
        super(fuelQuantity, fuelConsumption + ADDITIONAL_COST);
    }

    @Override
    public void refuel(double amount){
        super.refuel(amount * 0.95);
    }
}
