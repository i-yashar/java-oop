import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Map<String, Team> teams = new HashMap<>();

        while(true){
            String[] tokens = scanner.nextLine().split(";");

            if(tokens[0].equals("END"))
                break;

            switch (tokens[0]){
                case "Team":
                    String teamName = tokens[1];
                    Team newTeam = new Team(teamName);

                    teams.putIfAbsent(teamName, newTeam);
                    break;
                case "Add":
                    teamName = tokens[1];
                    String playerName = tokens[2];

                    if(!teams.containsKey(teamName)){
                        throw new IllegalArgumentException("Team " + teamName + " does not exist.");
                    }

                    Player newPlayer = new Player(playerName, Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4]), Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6]), Integer.parseInt(tokens[7]));
                    teams.get(teamName).addPlayer(newPlayer);
                    break;
                case "Remove":
                    teamName = tokens[1];
                    playerName = tokens[2];
                    teams.get(teamName).removePlayer(playerName);
                    break;
                case "Rating":
                    teamName = tokens[1];

                    if(!teams.containsKey(teamName)){
                        throw new IllegalArgumentException("Team " + teamName + " does not exist.");
                    }

                    System.out.println(teamName + " - " + Math.round(teams.get(teamName).getRating()));
                    break;
            }
        }
    }
}
