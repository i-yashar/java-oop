import java.util.*;

public class Main {

    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        String peopleInput = scanner.nextLine();
//        String productsInput = scanner.nextLine();
//
//        Map<String, Person> people = parsePeople(peopleInput);
//        Map<String, Product> products = parseProducts(productsInput);
//
//        while(true){
//            String input = scanner.nextLine();
//
//            if(input.equals("END")) break;
//
//            String name = input.split("\\s+")[0];
//            String product = input.split("\\s+")[1];
//
//            people.get(name).buyProduct(products.get(product));
//        }
//
//        for (Person person : people.values()) {
//            System.out.println(person);
//        }
    }

//    private static Map<String, Product> parseProducts(String input) {
//        String[] tokens = input.split(";");
//
//        Map<String, Product> products = new LinkedHashMap<>();
//
//        for (String token : tokens) {
//            Product product = new Product(token.substring(0, token.indexOf("=")), Double.parseDouble(token.substring(token.indexOf("=") + 1)));
//            products.put(token.substring(0, token.indexOf("=")), product);
//        }
//
//        return products;
//    }
//
//    private static Map<String, Person> parsePeople(String input) {
//        String[] tokens = input.split(";");
//
//        Map<String, Person> people = new LinkedHashMap<>();
//
//        for (String token : tokens) {
//            Person person = new Person(token.substring(0, token.indexOf("=")), Double.parseDouble(token.substring(token.indexOf("=") + 1)));
//            people.put(token.substring(0, token.indexOf("=")), person);
//        }
//
//        return people;
//    }
}
